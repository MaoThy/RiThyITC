@extends('layouts.master')
@section('content')
    <h1>Home Page</h1>
    <hr>
@endsection