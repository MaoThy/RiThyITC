@extends('layouts.master')
@section('content')
    <h1>About Page</h1>
    <hr>
@endsection