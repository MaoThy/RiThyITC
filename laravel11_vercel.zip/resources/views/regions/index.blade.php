@extends('layouts.master')
@section('content')
    <h1>Region</h1>
    <hr>
    <ul>
        @foreach ($rg as $r)
            <li>{{ $r->name }} - (<span class="text-danger">{{ $r->total }}</span>)នាក់</li>
        @endforeach
    </ul>
    {{ $rg->links() }}
@endsection
