@extends('layouts.master')

@section('content')
    <h1 class="text-primary">Customers List</h1>
    <div class="row">
        <div class="col-sm-1">
            <a href="{{ url('customer/create') }}" class="btn btn-primary btn-sm">Create</a>
        </div>
        <div class="col-sm-5">
            <form action="{{ url('customer/search') }}" method="GET">
                <input type="text" name="q" id="" value="{{ $q ?? '' }}">
                <button>Search</button>
            </form>
        </div>
    </div>

    @if (Session::has('success'))
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <p>{{ session('success') }}</p>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    @endif

    <table class="table table-sm table-bordered">
        <thead>
            <tr>
                <th>#</th>
                <th>Photo</th>
                <th>Name</th>
                <th>Gender</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Address</th>
                <th>Region</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $page = request('page', 1); // Get the current page or default to 1
            $i = config('app.row') * ($page - 1) + 1;
            ?>
            @if ($customers->isNotEmpty())
                @foreach ($customers as $c)
                    <tr>
                        <td>{{ $i++ }}</td>
                        <td>
                            @if ($c->photo)
                                <img src="{{ asset($c->photo) }}" alt="" width="27">
                            @else
                                <span>No photo</span>
                            @endif
                        </td>
                        <td>{{ $c->name }}</td>
                        <td>{{ $c->gender }}</td>
                        <td>{{ $c->email }}</td>
                        <td>{{ $c->phone }}</td>
                        <td>{{ $c->address }}</td>
                        <td>{{ $c->gname }}</td>
                        <td>
                            <a href="{{ route('customer.delete', $c->id) }}" class="btn btn-danger btn-sm"
                                onclick="return confirm('Do you want to delete?')">Delete</a>
                            <a href="{{ route('customer.edit', $c->id) }}" class="btn btn-success btn-sm">Edit</a>
                        </td>
                    </tr>
                @endforeach
            @else
                <tr>
                    <td colspan="9" class="text-center">No customers found.</td>
                </tr>
            @endif
        </tbody>
    </table>

    <!-- Pagination Links -->
    @if ($customers->hasPages())
        <div>
            <ul class="pagination">
                <!-- Previous Page Link -->
                @if ($customers->onFirstPage())
                    <li class="page-item disabled"><span class="page-link">Previous</span></li>
                @else
                    <li class="page-item">
                        <a class="page-link" href="{{ $customers->previousPageUrl() }}&q={{ $q }}">Previous</a>
                    </li>
                @endif

                <!-- Page Number Links -->
                @foreach ($customers->getUrlRange(1, $customers->lastPage()) as $page => $url)
                    <li class="page-item {{ $page == $customers->currentPage() ? 'active' : '' }}">
                        <a class="page-link" href="{{ $url }}&q={{ $q }}">{{ $page }}</a>
                    </li>
                @endforeach

                <!-- Next Page Link -->
                @if ($customers->hasMorePages())
                    <li class="page-item">
                        <a class="page-link" href="{{ $customers->nextPageUrl() }}&q={{ $q }}">Next</a>
                    </li>
                @else
                    <li class="page-item disabled"><span class="page-link">Next</span></li>
                @endif
            </ul>
        </div>
    @endif
    <div>
        Total : {{ $total }} , Male : {{ $male }}, Female : {{ $female }}, Min Rate:
        {{ $min }}, Max Rate:{{ $max }}, Sum Rate:{{ $sum }}
    </div>
@endsection
