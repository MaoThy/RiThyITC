@extends('layouts.master')
@section('content')
    <h1>Create Product</h1>
    <hr>
    <!-- Display Flash Message -->
    @if (session('success'))
        <div class="alert alert-success">
            {{ session('success') }}
        </div>
    @endif
    <form action="{{ route('product.sell') }}" method="POST">
        @csrf
        <div class="row">
            <div class="col-sm-8">
                <div class="form-group row">
                    <label for="pname" class="col-sm-3">Product Name</label>
                    <div class="col-sm-9">
                        <input type="text" class="form-control" id="pname" name="pname"
                            value="{{ old('pname', $pname ?? '') }}">
                    </div>
                </div>
                <div class="form-group row mt-3">
                    <label for="qty" class="col-sm-3">Quantity</label>
                    <div class="col-sm-9">
                        <input type="text" class="form-control" id="qty" name="qty"
                            value="{{ old('qty', $qty ?? '') }}">
                    </div>
                </div>
                <div class="form-group row mt-3">
                    <label for="price" class="col-sm-3">Unit Price</label>
                    <div class="col-sm-9">
                        <input type="text" class="form-control" id="price" name="price"
                            value="{{ old('price', $price ?? '') }}">
                    </div>
                </div>
                <div class="form-group row mt-3">
                    <label for="disc" class="col-sm-3">Discount(%)</label>
                    <div class="col-sm-9">
                        <input type="text" class="form-control" id="disc" name="disc"
                            value="{{ old('disc', $disc ?? '') }}">
                    </div>
                </div>
                <div class="form-group row mt-3">
                    <label for="total" class="col-sm-3">Total($)</label>
                    <div class="col-sm-9">
                        <input type="text" class="form-control" id="total" name="total" disabled
                            value="{{ $total ?? '' }}">
                    </div>
                </div>
                <div class="form-group row mt-3">
                    <label class="col-sm-3"></label>
                    <div class="col-sm-9">
                        <button class="btn btn-primary">Submit</button>
                    </div>
                </div>
            </div>
        </div>
    </form>
@endsection
