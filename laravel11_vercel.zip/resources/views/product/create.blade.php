@extends('layouts.master')
@section('content')
    <h1>Create Product</h1>
    <hr>
    <!-- Display Flash Message -->
    @if (session('success'))
        <div class="alert alert-success">
            {{ session('success') }}
        </div>
    @endif
    <form action="{{ route('product.save') }}" method="POST">
        @csrf
        <div class="row">
            <div class="col-sm-8">
                <div class="form-group row">
                    <label for="name" class="col-sm-3">Product Name</label>
                    <div class="col-sm-9">
                        <input type="text" class="form-control" id="name" name="name"
                            value="{{ old('name', $name ?? '') }}">
                    </div>
                </div>
                <div class="form-group row mt-3">
                    <label for="quantity" class="col-sm-3">Quantity</label>
                    <div class="col-sm-9">
                        <input type="text" class="form-control" id="quantity" name="quantity"
                            value="{{ old('quantity', $quantity ?? '') }}">
                    </div>
                </div>
                <div class="form-group row mt-3">
                    <label for="unitPrice" class="col-sm-3">Unit Price</label>
                    <div class="col-sm-9">
                        <input type="text" class="form-control" id="unitPrice" name="unitPrice"
                            value="{{ old('unitPrice', $unitPrice ?? '') }}">
                    </div>
                </div>
                <div class="form-group row mt-3">
                    <label for="discount" class="col-sm-3">Discount(%)</label>
                    <div class="col-sm-9">
                        <input type="text" class="form-control" id="discount" name="discount"
                            value="{{ old('discount', $discount ?? '') }}">
                    </div>
                </div>
                <div class="form-group row mt-3">
                    <label for="total" class="col-sm-3">Total($)</label>
                    <div class="col-sm-9">
                        <input type="text" class="form-control" id="total" name="total" disabled
                            value="{{ $total ?? '' }}">
                    </div>
                </div>
                <div class="form-group row mt-3">
                    <label class="col-sm-3"></label>
                    <div class="col-sm-9">
                        <button class="btn btn-primary">Submit</button>
                    </div>
                </div>
            </div>
        </div>
    </form>
@endsection
