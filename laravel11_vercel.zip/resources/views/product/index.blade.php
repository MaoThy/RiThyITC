@extends('layouts.master')
@section('css')
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }

        th,
        td {
            padding: 10px;
            border: 1px solid #ccc;
            text-align: left;
        }

        .pagination {
            display: flex;
            justify-content: center;
            margin-top: 20px;
        }

        .pagination .page-item .page-link {
            padding: 0.5rem 0.75rem;
            font-size: 14px;
            border-radius: 5px;
        }

        .pagination .page-item .page-link:hover {
            background-color: #f0f0f0;
        }

        .pagination .page-item.active .page-link {
            background-color: #007bff;
            color: #fff;
            border-color: #007bff;
        }
    </style>
@endsection
@section('content')
    <h1 class="text-primary">Product List</h1>
    <p>
        <a href="{{ url('product/create') }}" class="btn btn-primary btn-sm">Create</a>
    </p>
    @if (Session::has('success'))
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <p>{{ session('success') }}</p>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>

        </div>
    @endif
    <table class="table table-sm table-bordered">
        <thead>
            <tr>
                <th>#</th>
                <th>Name</th>
                <th>Quantity</th>
                <th>Unit Price</th>
                <th>Discount (%)</th>
                <th>Total ($)</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $page = @$_GET['page'];
            if (!$page) {
                $page = 1;
            }
            $i = config('app.row') * ($page - 1) + 1;
            
            ?>
            @foreach ($product as $p)
                <tr>
                    <td>{{ $i++ }}</td>
                    <td>{{ $p->name }}</td>
                    <td>{{ $p->quantity }}</td>
                    <td>{{ $p->unitPrice }}</td>
                    <td>{{ $p->discount }}</td>
                    <td>{{ $p->total }}</td>
                    <td>
                        {{-- {{ url('customer/delete/' . $c->id) }} --}}
                        <a href="{{ route('customer.delete', $p->id) }}" class="btn btn-danger btn-sm"
                            onclick="return confirm('You wamt tp Delete?')">Delete</a>
                        <a href="{{ route('customer.edit', $p->id) }}" class="btn btn-success btn-sm">Edit</a>
                    </td>
                </tr>
            @endforeach
        </tbody>
    </table>
    <!-- Pagination Links -->
    {{-- <div>
        <ul class="pagination">
            <!-- Previous Page Link -->
            @if ($product->onFirstPage())
                <li class="page-item disabled"><span class="page-link">Previous</span></li>
            @else
                <li class="page-item"><a class="page-link" href="{{ $product->previousPageUrl() }}">Previous</a></li>
            @endif

            <!-- Page Number Links -->
            @foreach ($product->getUrlRange(1, $product->lastPage()) as $page => $url)
                <li class="page-item {{ $page == $product->currentPage() ? 'active' : '' }}">
                    <a class="page-link" href="{{ $url }}">{{ $page }}</a>
                </li>
            @endforeach

            <!-- Next Page Link -->
            @if ($product->hasMorePages())
                <li class="page-item"><a class="page-link" href="{{ $product->nextPageUrl() }}">Next</a></li>
            @else
                <li class="page-item disabled"><span class="page-link">Next</span></li>
            @endif
        </ul>
    </div> --}}
@endsection
