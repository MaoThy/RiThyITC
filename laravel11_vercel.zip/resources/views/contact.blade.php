@extends('layouts.master')
@section('content')
    <h1>Contact Page</h1>
    <hr>
@endsection