@extends('layouts.master')
@section('content')
    <h1>User Register</h1>
    <hr>
    <form action="{{ url('register/save') }}" method="POST">
        @csrf
        <p>
            Name: <input type="text" name="name">
        </p>
        <p>
            Phone: <input type="text" name="phone">
        </p>
        <p>
            Email: <input type="email" name="email">
        </p>
        <p>
            <button type="submit">Submit</button>
        </p>
    </form>
@endsection
    
