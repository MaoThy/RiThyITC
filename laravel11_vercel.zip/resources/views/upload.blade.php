@extends('layouts.master')
@section('css')
    <style>
        #photos .img {
            margin: 5px;
            display: inline-block;
            border: 2px solid green
        }
    </style>
@endsection
@section('content')
 
    <h1>Upload File</h1>
    <hr>
    <form action="{{ 'upload/save' }}"method="POST" enctype="multipart/form-data">
        @csrf
        <p>
            File : <input type="file" id="photo" name="photo[]" accept="image/*" required multiple
                onchange="preview(event)">
        </p>
        {{-- <p>
                <img src="" alt="" id="img" width="150">
        </p> --}}
        <div id="photos">

        </div>
        <p>
            <button>Upload</button>
        </p>
        @if (Session::has('error'))
            <p>
                {{ Session::get('error') }}
            </p>
        @endif
        @if (Session::has('success'))
            <p>
                {{ Session::get('success') }}
            </p>
            <p>
                {{ Session::get('error') }}
            </p>
        @endif
    </form>
@endsection
@section('js')
    <script>
        function preview(evt) {
            // let img = document.getElementById('img');
            let photos = evt.target.files;
            let img = "";
            // alert(photos.length);
            for (let i = 0; i < photos.length; i++) {
                let src = URL.createObjectURL(evt.target.files[i]);
                img += "<img src='" + src + "'width='150' class='img'>";
            }
            document.getElementById('photos').innerHTML = img;
        }
    </script>
@endsection
