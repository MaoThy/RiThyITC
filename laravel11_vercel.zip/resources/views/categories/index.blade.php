@extends('layouts.master')

@section('content')
    <h1 class="text-primary">Categories List</h1>
    <div class="row">
        <div class="col-sm-1">
            <a href="{{ route('category.create') }}" class="btn btn-primary btn-sm">Create</a>
        </div>
    </div>

    @if (Session::has('success'))
        <div class="alert alert-success alert-dismissible fade show" role="alert">
            <p>{{ session('success') }}</p>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
    @endif

    <table class="table table-sm table-bordered">
        <thead>
            <tr>
                <th>#</th>

                <th>Name</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php
            $page = request('page', 1); // Get the current page or default to 1
            $i = config('app.row') * ($page - 1) + 1;
            ?>
            @if (isset($cats) && $cats->count() > 0)
                @foreach ($cats as $c)
                    <tr>
                        <td>{{ $i++ }}</td>
                        <td>{{ $c->name }}</td>
                        <td>
                            <a href="{{route('category.delete', $c->id)}}" class="btn btn-danger btn-sm"
                                onclick="return confirm('Do you want to delete?')">Delete</a>
                            <a href="{{ route('category.edit', $c->id) }}" class="btn btn-success btn-sm">Edit</a>
                        </td>
                    </tr>
                @endforeach
            @else
                <tr>
                    <td colspan="8" class="text-center">No cats found.</td>
                </tr>
            @endif
        </tbody>
    </table>

    <!-- Pagination Links -->
    @if (isset($cats))
        <div>
            <ul class="pagination">
                <!-- Previous Page Link -->
                @if ($cats->onFirstPage())
                    <li class="page-item disabled"><span class="page-link">Previous</span></li>
                @else
                    <li class="page-item">
                        <a class="page-link" href="{{ $cats->previousPageUrl() }}">Previous</a>
                    </li>
                @endif

                <!-- Page Number Links -->
                @foreach ($cats->getUrlRange(1, $cats->lastPage()) as $page => $url)
                    <li class="page-item {{ $page == $cats->currentPage() ? 'active' : '' }}">
                        <a class="page-link" href="{{ $url }}">{{ $page }}</a>
                    </li>
                @endforeach

                <!-- Next Page Link -->
                @if ($cats->hasMorePages())
                    <li class="page-item">
                        <a class="page-link" href="{{ $cats->nextPageUrl() }}">Next</a>
                    </li>
                @else
                    <li class="page-item disabled"><span class="page-link">Next</span></li>
                @endif
            </ul>
        </div>
    @endif
@endsection
