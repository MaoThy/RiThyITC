<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
use App\Http\Controllers\AboutController;
use App\Http\Controllers\ContactController;
use App\Http\Controllers\RegisterController;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\UploadController; // Ensure this class exists in the specified namespace
use App\Http\Controllers\CustomerController;
use App\Http\Controllers\CategoryController;
use App\Http\Controllers\RegionController;

Route::get('/', function () {
    return view('welcome');
});

Route::get('/about', [AboutController::class, 'index']);
Route::get('/contact', [ContactController::class, 'index']);
Route::view('register', 'register');
Route::post('register/save', [RegisterController::class, 'save'])->name('register.save');

Route::get('/product', [ProductController::class, 'index'])->name('product.index');
Route::get('product/sell', [ProductController::class, 'showSellForm'])->name('product.sell.form');
Route::post('product/sell', [ProductController::class, 'sell'])->name('product.sell');

Route::get('/product/create', [ProductController::class, 'create'])->name('product.create');
Route::post('/product/save', [ProductController::class, 'save'])->name('product.save');


Route::get('upload', [UploadController::class, 'index']);
Route::post('upload/save', [UploadController::class, 'save'])->name('upload.save');

Route::get('/customer', [CustomerController::class, 'index']);
Route::get('/customer/create', [CustomerController::class, 'create'])->name('customer.create');
Route::get('/customer/search', [CustomerController::class, 'search'])->name('customer.search');

Route::get('/customer/delete/{id}', [CustomerController::class, 'delete'])->name('customer.delete');
Route::get('/customer/edit/{id}', [CustomerController::class, 'edit'])->name('customer.edit');
Route::post('customer/save', [CustomerController::class, 'save'])->name('customer.save');
Route::post('customer/update', [CustomerController::class, 'update'])->name('customer.update');

Route::resource('category', CategoryController::class)->except(['show', 'destroy']);
Route::get('category/delete/{id}', [CategoryController::class, 'delete'])->name('category.delete');
Route::patch('category/{id}', [CategoryController::class, 'update'])->name('category.update');

Route::get('region', [RegionController::class, 'index']);
