<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Http;

class ProductController extends Controller
{


    public function index()
    {
        // Fetch all products
        $product = DB::table('product')->get();

        // Pass the data to the view
        return view('product.index', compact('product'));
    }

    public function create()
    {
        return view('product.create');
    }
    public function save(Request $request)
    {
        // Validate the request data
        $request->validate([
            'name' => 'required|string|max:255',
            'quantity' => 'required|integer',
            'unitPrice' => 'required|numeric',
            'discount' => 'nullable|numeric',
        ]);

        // Calculate the total
        $total = $request->quantity * $request->unitPrice;
        if ($request->discount) {
            $total -= $total * ($request->discount / 100);
        }

        // Save the product to the database
        DB::table('product')->insert([
            'name' => $request->name,
            'quantity' => $request->quantity,
            'unitPrice' => $request->unitPrice,
            'discount' => $request->discount,
            'total' => $total,
            'action' => 1, // Assuming 'action' is a required field
        ]);

        // Redirect back with a success message
        return redirect()->route('product.index')->with('success', 'Product saved successfully!');
    }










    public function showSellForm()
    {
        $data['total'] = ""; // Initialize total as empty
        return view('sell', $data);
    }

    // Handle the form submission (POST request)

    public function sell(Request $request)
    {
        // Validate the input
        $request->validate([
            'pname' => 'required|string',
            'qty' => 'required|numeric',
            'price' => 'required|numeric',
            'disc' => 'nullable|numeric',
        ]);

        // Retrieve form inputs
        $qty = $request->qty;
        $up = $request->price;
        $disc = $request->disc ?? 0; // Default discount to 0 if not provided

        // Calculate total
        $total = $qty * $up * (1 - $disc / 100);

        // Prepare Telegram API details
        $botToken = "8198599194:AAFjUtqav1_eNGQHbSEq1CsPSrWAL5Vh9f0";
        $chatId = "1069857987";
        $message = "📢 *Product Sold!*\n\n"
            . "🛒 *Name:* {$request->pname}\n"
            . "📦 *Quantity:* {$qty}\n"
            . "💰 *Price:* \${$up}\n"
            . "🎯 *Discount:* {$disc}%\n"
            . "✅ *Total:* \${$total}";

        $telegramApiUrl = "https://api.telegram.org/bot{$botToken}/sendMessage";

        try {
            Http::withoutVerifying()->get($telegramApiUrl, [
                'chat_id' => $chatId,
                'text' => $message,
                'parse_mode' => 'Markdown'
            ]);
        } catch (\Exception $e) {
            // \Log::error("Telegram API Error: " . $e->getMessage());
        }

        // Flash a success message to the session
        session()->flash('success', 'Product details submitted successfully! Total calculated: $' . number_format($total, 2));

        // Return the view with data
        return view('sell', [
            'total' => $total,
            'pname' => $request->pname,
            'qty' => $request->qty,
            'price' => $request->price,
            'disc' => $request->disc,
        ]);
    }
}
