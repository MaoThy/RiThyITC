<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class RegisterController extends Controller
{
    public function save(Request $r)
    {
        // dd($r->all()); // Dump and die to check the submitted data
        $name = $r->name;
        $phone = $r->phone;
        $email = $r->email;

        echo $name . "," . $phone . "," . $email;
    }
}
