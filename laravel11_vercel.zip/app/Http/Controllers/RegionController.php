<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class RegionController extends Controller
{
    public function index()
    {
        // $rg = DB::table('regions')->get();
        // $rg = DB::select("select * from regions order by id desc ");
        $rg = DB::select("
            SELECT regions.name, COUNT(customers.id) AS total 
            FROM customers
            INNER JOIN regions ON customers.region_id = regions.id
            GROUP BY regions.name
        ");

        $rg = DB::table('customers')
            ->join('regions', 'customers.region_id', 'regions.id')
            ->select('regions.name', DB::raw("count(customers.id) as total"))
            ->groupBy('regions.name')
            ->paginate(2);
        return view('regions.index', compact('rg'));
        dd($rg);
        // return view()
    }
}
