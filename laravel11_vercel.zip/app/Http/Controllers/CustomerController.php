<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class CustomerController extends Controller
{
    public function index()
    {
        $q = request('q', ''); // Get the 'q' parameter from the request or default to an empty string
        $id = array(1, 3, 5);
        $data['customers'] = DB::table('customers')
            // ->where('active', 1)
            // ->where('gender', 'F')
            // ->where('id', '>', 3)
            // ->where([
            //     ['active', '=', 1], // Only active customers
            //     ['gender', '=', 'F'], // Gender is 'F'
            //     ['id', '>', 3] // ID is greater than 3
            // ])
            // ->where('gender', 'F')
            // ->orWhere('id', '>', 2)
            // ->where('id', 1)
            // ->orWhere('id', 3)
            // ->orWhere('id', 5)
            // ->whereIn('id', [1, 3, 5])
            // ->whereIn('id', $id)
            // ->whereNot('id', $id)
            // ->where('id','>=',3)
            // ->where('id','<=',5)
            // ->whereBetween('id',[3,5])
            // ->whereNull('phone')
            // ->whereNotNull('phone')
            // ->whereDate('create_at', '2019-11-13')
            // ->whereYear('create_at', 2018)
            // ->whereYear('create_at', 2019)
            // ->whereMonth('create_at', 11)
            // ->where('active', 1)
            // ->where(function ($q) {
            //     $q = $q->where('name', 'like', 's%')
            //         ->orWhere('phone', 'like', '012%')
            //         ->orWhere('email', 'like', '%gmail.com');
            // })
            // ->join('regions', 'customers.region_id', 'regions.id')
            ->leftJoin('regions', 'customers.region_id', 'regions.id')
            ->where('customers.active', 1)
            ->orderBy('customers.name', 'desc')  // Corrected the orderBy clause
            ->select('customers.*', 'regions.name as gname')
            ->paginate(config('app.row'))
            ->appends($data['q'] = $q); // Append the search query to pagination links
        $data['total'] = DB::table('customers')
            ->where('active', 1)
            ->count();
        $data['male'] = DB::table('customers')
            ->where('active', 1)
            ->where('gender', 'M')
            ->count();
        $data['female'] = DB::table('customers')
            ->where('active', 1)
            ->where('gender', 'F')
            ->count();
        $data['min'] = DB::table('customers')
            ->where('active', 1)
            ->min('rate');
        $data['max'] = DB::table('customers')
            ->where('active', 1)
            ->max('rate');
        $data['sum'] = DB::table('customers')
            ->where('active', 1)
            ->sum('rate');       
        return view('customers.index', $data); // Use compact()
    }

    public function search(Request $r)
    {
        $q = $r->q;
        $customers = DB::table('customers')
            ->where('active', 1)
            ->where(function ($query) use ($q) {
                $query->orWhere('name', 'like', "%{$q}%")
                    ->orWhere('email', 'like', "%{$q}%")
                    ->orWhere('phone', 'like', "%{$q}%")
                    ->orWhere('address', 'like', "%{$q}%");
            })
            ->orderBy('name', 'desc')
            ->paginate(config('app.row'))
            ->appends(['q' => $q]); // Append the search query to pagination links

        return view('customers.index', compact('q', 'customers')); // Use compact()
    }
    public function create()
    {
        $data['regions'] = DB::table('regions')->get();
        return view('customers.create', $data);
    }

    public function save(Request $r)
    {
        // $data = $r->except('_token');
        $data = array(
            'name' => $r->name,
            'gender' => $r->gender,
            'email' => $r->email,
            'phone' => $r->phone,
            'address' => $r->address,
            'region_id' => $r->region_id
        );
        if ($r->photo) {
            $data['photo'] = $r->file('photo')->store('uploads/customers', 'custom');
        }
        // dd($data);
        $i = DB::table('customers')->insert($data);
        if ($i) {
            return redirect('customer/create')
                ->with('success', 'Data has been saved!');
        } else {
            return redirect('customer/create')
                ->with('error', 'Fail to save data!');
        }
    }
    public function edit($id)
    {
        $customer = DB::table('customers')->find($id);
        $regions = DB::table('regions')->get();
        // ->where('id', $id)
        // ->first();
        return view('customers.edit', compact('customer', 'regions'));
    }

    public function delete($id)
    {
        $i = DB::table('customers')
            ->where('id', $id)
            // ->delete();
            ->update(['active' => 0]);
        return redirect('customer')
            ->with('success', 'Data has been removed!');
    }

    public function update(Request $r)
    {

        $data = $r->except('_token', 'id', 'photo');
        // dd($data);
        if ($r->photo) {
            $data['photo'] = $r->file('photo')->store('uploads/customers', 'custom');
        }
        $i = DB::table('customers')
            ->where('id', $r->id)
            ->update($data);
        if ($i) {
            return redirect('customer/edit/' . $r->id)
                ->with('success', 'Data has been updated!');
        } else {
            return redirect('customer/edit/' . $r->id)
                ->with('error', 'Fail to update data!');
        }
    }
}
